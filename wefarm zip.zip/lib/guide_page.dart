import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'plant_detail_page.dart';
import 'package:wefarm/models/plant_model.dart';
import 'package:wefarm/models/plant_provider.dart';
import 'tracker_page.dart';
import 'custom_drawer.dart';

class GuidePage extends StatelessWidget {
  final String plantName;
  final String imagePath;
  final String plantGuide;

  const GuidePage({
    super.key,
    required this.plantName,
    required this.imagePath,
    required this.plantGuide,
  });

  @override
  Widget build(BuildContext context) {
    final plantProvider = Provider.of<PlantProvider>(context, listen: false);

    return Scaffold(
      endDrawer: const CustomDrawer(currentIndex: -1),
      appBar: AppBar(
        title: Text(plantName),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () => Scaffold.of(context).openEndDrawer(),
            ),
          ),
        ],
        backgroundColor: const Color(0xFFf5bd52),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Plant Image
            Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  imagePath,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      const Center(child: Icon(Icons.image_not_supported)),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Guide Title
            const Text(
              'Guide',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),

            // Guide Content
            Text(
              plantGuide,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),

            // Complete Source
            const Text(
              'Complete Source:',
              style: TextStyle(
                fontStyle: FontStyle.italic,
                fontSize: 16,
              ),
            ),
            InkWell(
              onTap: () => launchUrlString(
                  'https://www.kompas.com/homey/read/2024/03/26/184000276/teknik-budidaya-cabai-rawit-yang-benar?page=2'),
              child: Text(
                'Cara Menanam $plantName',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontStyle: FontStyle.italic,
                  fontSize: 16,
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),

            // Product Recommendations
            const Text(
              'Product Recommendation:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 10),
            _buildProductLink('Link Pot', 'https://tokopedia.com/pot-tanaman'),
            _buildProductLink(
                'Link Media Tanam', 'https://tokopedia.com/media-tanam'),
            _buildProductLink(
                'Link Bibit', 'https://tokopedia.com/bibit-tanaman'),
            const Divider(),
            const SizedBox(height: 20),

            // Start Planting Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text("Konfirmasi"),
                      content: Text("Mulai menanam $plantName?"),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text("Batal"),
                        ),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFf5bd52),
                          ),
                          onPressed: () {
                            Navigator.pop(context); // Tutup dialog konfirmasi

                            final selectedPlant =
                                plantProvider.availablePlants.firstWhere(
                              (plant) => plant.name == plantName,
                              orElse: () => Plant(
                                name: plantName,
                                duration: '3-4 Bulan',
                                startDate: DateTime.now(),
                                tasks: [
                                  PlantTask(name: "Penyiraman"),
                                  PlantTask(name: "Pemupukan"),
                                ],
                              ),
                            );

                            plantProvider.addPlant(selectedPlant);

                            // [BEGIN NAVIGATION CODE]
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => PlantDetailPage(
                                  plant: selectedPlant.copyWith(
                                    startDate: DateTime
                                        .now(), // Ensure start date is today
                                  ),
                                ),
                              ),
                            );
                            // [END NAVIGATION CODE]
                          },
                          child: const Text("Ya"),
                        ),
                      ],
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFf5bd52),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text(
                  'Start Planting',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // Others Experience Section
            const Text(
              'Others Experience',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),

            // User Experience 1
            _buildUserExperience(
              emoji: '🍟',
              name: 'Lena Syahada',
              review:
                  'Proses penanaman dan perawatan sangat mudah, cukup mengikuti petunjuk dari WeFarm dan serahkan kepada Tuhan untuk hasilnya',
            ),
            const SizedBox(height: 16),

            // User Experience 2
            _buildUserExperience(
              emoji: '🍟',
              name: 'Rifha Tania',
              review:
                  'Tidak cocok untuk tanah kering seperti di belakang rumah saya, sehingga tanaman mati di minggu ke 4',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductLink(String text, String url) {
    return InkWell(
      onTap: () => launchUrlString('https://www.tokopedia.com/'),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Row(
          children: [
            const Icon(Icons.link, color: Colors.blue),
            const SizedBox(width: 8),
            Text(
              text,
              style: const TextStyle(
                color: Colors.blue,
                decoration: TextDecoration.underline,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserExperience({
    required String emoji,
    required String name,
    required String review,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                emoji,
                style: const TextStyle(fontSize: 20),
              ),
              const SizedBox(width: 8),
              Text(
                name,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            review,
            style: const TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }
}
