import 'package:flutter/material.dart';
import 'package:wefarm/login_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  bool _isPasswordVisible = false; // State untuk toggle visibility password
  bool _isConfirmPasswordVisible =
      false; // State untuk toggle visibility confirm password
  bool _isChecked = false; // State untuk checkbox Privacy Policy

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(28.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Logo dan Teks "Sign Up"
              Row(
                mainAxisAlignment:
                    MainAxisAlignment.start, // Posisi logo dan teks di tengah
                children: [
                  // Logo
                  Image.asset(
                    'assets/logo_wefarm.png', // Path ke logo Anda
                    width: 125, // Ukuran logo disesuaikan
                    height: 125,
                  ),
                  SizedBox(width: 8.0), // Jarak antara logo dan teks
                  // Teks "Sign Up"
                  Text(
                    "Sign Up",
                    style: TextStyle(
                      fontSize: 40,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 28.0),

              // Kotak untuk Username, Email, Nomor Telepon, Alamat, Password, Confirm Password
              Center(
                child: Container(
                  width: MediaQuery.of(context).size.width *
                      0.9, // Lebar kotak 90% dari layar
                  decoration: BoxDecoration(
                    color:
                        Colors.white, // Warna latar belakang container (putih)
                    border: Border.all(
                        color: Colors.grey.withOpacity(0.5)), // Border
                    borderRadius:
                        BorderRadius.circular(10.0), // Sudut melengkung
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3), // Warna bayangan
                        spreadRadius: 2, // Seberapa jauh bayangan menyebar
                        blurRadius: 5, // Seberapa blur bayangan
                        offset: Offset(0, 3), // Posisi bayangan (x, y)
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.symmetric(
                      vertical: 4.0,
                      horizontal: 16.0), // Padding vertikal diperkecil
                  child: Column(
                    children: [
                      // Input Username
                      TextField(
                        decoration: InputDecoration(
                          labelText: 'Username',
                          border:
                              InputBorder.none, // Menghilangkan border default
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 8.0,
                              horizontal: 8.0), // Padding vertikal diperkecil
                        ),
                      ),
                      Divider(
                          color: Colors.grey.withOpacity(0.5)), // Garis pemisah

                      // Input Email
                      TextField(
                        decoration: InputDecoration(
                          labelText: 'Email',
                          border:
                              InputBorder.none, // Menghilangkan border default
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 8.0,
                              horizontal: 8.0), // Padding vertikal diperkecil
                        ),
                      ),
                      Divider(
                          color: Colors.grey.withOpacity(0.5)), // Garis pemisah

                      // Input Nomor Telepon
                      TextField(
                        decoration: InputDecoration(
                          labelText: 'Phone Number',
                          border:
                              InputBorder.none, // Menghilangkan border default
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 8.0,
                              horizontal: 8.0), // Padding vertikal diperkecil
                        ),
                      ),
                      Divider(
                          color: Colors.grey.withOpacity(0.5)), // Garis pemisah

                      // Input Alamat
                      TextField(
                        decoration: InputDecoration(
                          labelText: 'Address',
                          border:
                              InputBorder.none, // Menghilangkan border default
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 8.0,
                              horizontal: 8.0), // Padding vertikal diperkecil
                        ),
                      ),
                      Divider(
                          color: Colors.grey.withOpacity(0.5)), // Garis pemisah

                      // Input Password
                      TextField(
                        obscureText:
                            !_isPasswordVisible, // Toggle visibility password
                        decoration: InputDecoration(
                          labelText: 'Password',
                          border:
                              InputBorder.none, // Menghilangkan border default
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 8.0,
                              horizontal: 8.0), // Padding vertikal diperkecil
                          suffixIcon: IconButton(
                            icon: Icon(
                              _isPasswordVisible
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                            onPressed: () {
                              setState(() {
                                _isPasswordVisible =
                                    !_isPasswordVisible; // Toggle state
                              });
                            },
                          ),
                        ),
                      ),
                      Divider(
                          color: Colors.grey.withOpacity(0.5)), // Garis pemisah

                      // Input Confirm Password
                      TextField(
                        obscureText:
                            !_isConfirmPasswordVisible, // Toggle visibility confirm password
                        decoration: InputDecoration(
                          labelText: 'Confirm Password',
                          border:
                              InputBorder.none, // Menghilangkan border default
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 8.0,
                              horizontal: 8.0), // Padding vertikal diperkecil
                          suffixIcon: IconButton(
                            icon: Icon(
                              _isConfirmPasswordVisible
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                            onPressed: () {
                              setState(() {
                                _isConfirmPasswordVisible =
                                    !_isConfirmPasswordVisible; // Toggle state
                              });
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16.0),

              // Checkbox untuk Privacy Policy dan Terms & Conditions
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Checkbox(
                    value: _isChecked,
                    onChanged: (bool? value) {
                      setState(() {
                        _isChecked = value ?? false;
                      });
                    },
                  ),
                  Expanded(
                    child: Text(
                      "I agree to the Terms & Conditions and Privacy Policy",
                      style: TextStyle(fontSize: 14),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 24.0),

              // Tombol Sign Up
              ElevatedButton(
                onPressed: () {
                  // Navigasi ke LoginScreen setelah register
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => LoginScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFf5bd52), // Warna tombol
                  foregroundColor: Colors.white, // Warna teks tombol
                  padding:
                      EdgeInsets.symmetric(vertical: 8.0, horizontal: 32.0),
                ),
                child: Text(
                  "Sign Up",
                  style: TextStyle(fontSize: 18),
                ),
              ),
              SizedBox(height: 8.0),

              // Opsi Sign Up dengan Google dan Facebook (Hanya Logo)
              Text(
                "Or sign up with",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                ),
              ),
              SizedBox(height: 8.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Tombol Sign Up dengan Google
                  IconButton(
                    onPressed: () {
                      // Aksi sign up dengan Google
                    },
                    icon: Image.asset(
                      'assets/google_logo.png', // Logo Google
                      width: 30, // Ukuran logo diubah menjadi 30
                      height: 30,
                    ),
                  ),
                  SizedBox(width: 8.0),

                  // Tombol Sign Up dengan Facebook
                  IconButton(
                    onPressed: () {
                      // Aksi sign up dengan Facebook
                    },
                    icon: Image.asset(
                      'assets/facebook_logo.png', // Logo Facebook
                      width: 30, // Ukuran logo diubah menjadi 30
                      height: 30,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8.0),

              // Tulisan "Already have an account? Login"
              TextButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => LoginScreen()),
                  );
                },
                child: Text("Already have an account? Login"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
