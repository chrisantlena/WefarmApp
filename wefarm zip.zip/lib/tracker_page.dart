import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'home_screen.dart';
import 'shop_page.dart';
import 'profile_page.dart';
import 'package:wefarm/models/plant_model.dart';
import 'package:wefarm/models/plant_provider.dart';
import 'package:wefarm/plant_detail_page.dart';
import 'guide_page.dart';
import 'custom_drawer.dart';

class TrackerPage extends StatefulWidget {
  const TrackerPage({super.key});

  @override
  State<TrackerPage> createState() => _TrackerPageState();
}

class _TrackerPageState extends State<TrackerPage> {
  int _currentIndex = 1; // Index untuk Tracker

  void _onNavItemTapped(int index) {
    if (index == _currentIndex) return;

    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0: // Home
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const HomeScreen()),
        );
        break;
      case 2: // Shop
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const ShopPage()),
        );
        break;
      case 3: // Profile
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const ProfilePage()),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final plantProvider = Provider.of<PlantProvider>(context);

    return Scaffold(
      endDrawer: const CustomDrawer(isMainScreen: true, currentIndex: 0),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text("Tracker"),
        actions: [
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () => Scaffold.of(context).openEndDrawer(),
            ),
          ),
        ],
        backgroundColor: const Color(0xFFf5bd52),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Add Plant Button
            _buildAddPlantButton(context),
            const SizedBox(height: 20),

            // Plant List
            Expanded(
              child: plantProvider.trackedPlants.isEmpty
                  ? const Center(child: Text("Belum ada tanaman yang dilacak"))
                  : ListView.builder(
                      itemCount: plantProvider.trackedPlants.length,
                      itemBuilder: (context, index) {
                        final plant = plantProvider.trackedPlants[index];
                        return _buildPlantCard(context, plant);
                      },
                    ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onNavItemTapped,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFFf5bd52),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.track_changes), label: 'Tracker'),
          BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart), label: 'Shop'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _buildAddPlantButton(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFFf5bd52)),
        borderRadius: BorderRadius.circular(8),
        color: const Color(0xFFf5bd52).withOpacity(0.1),
      ),
      child: InkWell(
        onTap: () => _showAddPlantDialog(context),
        child: const Row(
          children: [
            Icon(Icons.add_circle_outline, color: Color(0xFFf5bd52)),
            SizedBox(width: 12),
            Text(
              "Tambah Tanaman",
              style: TextStyle(
                color: Color(0xFFf5bd52),
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddPlantDialog(BuildContext context) {
    final plantProvider = Provider.of<PlantProvider>(context, listen: false);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Pilih Tanaman"),
        content: SizedBox(
          width: double.maxFinite,
          height: 300,
          child: ListView.builder(
            itemCount: plantProvider.availablePlants.length,
            itemBuilder: (context, index) {
              final plant = plantProvider.availablePlants[index];
              return ListTile(
                title: Text(plant.name),
                subtitle: Text(plant.duration),
                onTap: () {
                  Navigator.pop(context); // Tutup dialog
                  _navigateToGuidePage(context, plant); // Navigasi ke GuidePage
                },
              );
            },
          ),
        ),
      ),
    );
  }

  void _navigateToGuidePage(BuildContext context, Plant plant) {
    final plantData = Provider.of<PlantProvider>(context, listen: false)
        .allPlants
        .firstWhere((p) => p["name"] == plant.name);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => GuidePage(
          plantName: plantData["name"]!,
          imagePath: plantData["image"]!,
          plantGuide: plantData["guide"]!,
        ),
      ),
    );
  }

  void _navigateToDetail(Plant plant) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PlantDetailPage(plant: plant),
      ),
    );
  }

  Widget _buildPlantCard(BuildContext context, Plant plant) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        title: Text(
          plant.name,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Mulai: ${_formatDate(plant.startDate)}'),
            const SizedBox(height: 4),
            // Hanya tampilkan satu progress bar (warna kuning)
            LinearProgressIndicator(
              value: plant.progress,
              minHeight: 8,
              backgroundColor: Colors.grey[200], // Warna latar abu-abu
              color: const Color(0xFFf5bd52), // Warna kuning
            ),
            const SizedBox(height: 4),
            Text('${(plant.progress * 100).round()}%'),
          ],
        ),
        onTap: () => _navigateToDetail(plant),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}
