import 'package:flutter/material.dart';
import 'experience_model.dart';



class ExperienceProvider extends ChangeNotifier {
  final List<Experience> _myExperiences = [];
  final List<Experience> _othersExperiences = [];

  List<Experience> get myExperiences => _myExperiences;
  List<Experience> get othersExperiences => _othersExperiences;

  void addExperience(Experience experience) {
    _myExperiences.add(experience);
    notifyListeners();
  }

  void addCommunityExperience(Experience experience) {
    _othersExperiences.add(experience);
    notifyListeners();
  }

  void loadSampleData() {
    _othersExperiences.addAll([
      Experience(
        plantName: "Cabai Rawit",
        startDate: DateTime.now().subtract(const Duration(days: 90)),
        endDate: DateTime.now(),
        status: "completed",
        review: "Pertumbuhan cabai rawit cukup baik dengan perawatan rutin.",
        author: "Budi Santoso",
        createdAt: DateTime.now().subtract(const Duration(days: 5)),
      ),
    ]);
    notifyListeners();
  }
}