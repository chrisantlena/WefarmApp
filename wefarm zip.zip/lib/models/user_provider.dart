// user_provider.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'user_model.dart';

class UserProvider extends ChangeNotifier {
  User? _user;

  User? get user => _user;

  Future<void> loadUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userJson = prefs.getString('current_user');

    if (userJson != null) {
      _user = User.fromJson(json.decode(userJson));
    } else {
      _user = User(
        id: '1',
        name: 'Guest',
        email: 'guest@example.com',
        phone: '+62 812345678',
      );
    }
    notifyListeners();
  }

  Future<void> updateUser(User newUser) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('current_user', json.encode(newUser.toJson()));
    _user = newUser;
    notifyListeners();
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('current_user');
    _user = null;
    notifyListeners();
  }
}