import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'plant_model.dart';

class PlantProvider extends ChangeNotifier {
  // Daftar tanaman yang tersedia
  final List<Map<String, dynamic>> allPlants = [
    {
      "name": "Cabai Rawit",
      "duration": "3-4 Bulan",
      "image": "assets/Cabai_Rawit.jpg",
      "guide":
          "1. Pilih benih berkualitas, rendam dalam air hangat (50–55°C) selama 1 jam."
              "\n2. Semai benih di media tanah + pupuk kandang + sekam (2:1:1)."
              "\n3. Pindahkan bibit setelah 21–30 hari."
              "\n4. Olah lahan dengan pupuk dasar (NPK 15-15-15)."
              "\n5. Panen setelah 70–90 hari."
    },
    {
      "name": "Cabai Merah",
      "duration": "3-4 Bulan",
      "image": "assets/Cabai Merah.jpg",
      "guide": "1. Siapkan pot...\n2. Sebarkan biji...",
    },
    {
      "name": "Tomat Sayur",
      "duration": "2-3 Bulan",
      "image": "assets/Tomat sayur.jpg",
      "guide":
          "1. Siapkan pot yang memiliki lubang drainase...\n2. Sebarkan biji tomat sayur...",
    },
    {
      "name": "Cabai Hijau",
      "duration": "3-4 Bulan",
      "image": "assets/Cabai Hijau.jpg",
      "guide":
          "1. Siapkan pot yang memiliki lubang drainase...\n2. Sebarkan biji cabai hijau...",
    },
    {
      "name": "Cabai Keriting",
      "duration": "4-5 Bulan",
      "image": "assets/Cabai Keriting.jpg",
      "guide":
          "1. Siapkan pot yang memiliki lubang drainase...\n2. Sebarkan biji cabai keriting...",
    },
    {
      "name": "Cabai Gendot",
      "duration": "4-6 Bulan",
      "image": "assets/Cabai Gendot.jpg",
      "guide":
          "1. Siapkan pot yang memiliki lubang drainase...\n2. Sebarkan biji cabai gendat...",
    },
    {
      "name": "Tomat Ceri",
      "duration": "2-3 Bulan",
      "image": "assets/Tomat Cri.jpg",
      "guide":
          "1. Siapkan pot yang memiliki lubang drainase...\n2. Sebarkan biji tomat ceri...",
    },
    {
      "name": "Tomat Hijau",
      "duration": "2-3 Bulan",
      "image": "assets/Tomat Hijau.jpg",
      "guide":
          "1. Siapkan pot yang memiliki lubang drainase...\n2. Sebarkan biji tomat hijau...",
    },
    {
      "name": "Terong Putih",
      "duration": "3-4 Bulan",
      "image": "assets/Terong Putih.jpg",
      "guide":
          "1. Siapkan pot yang memiliki lubang drainase...\n2. Sebarkan biji terong putih...",
    },
    {
      "name": "Terong Ungu",
      "duration": "2-3 Bulan",
      "image": "assets/Terong Ungu.jpg",
      "guide":
          "1. Siapkan pot yang memiliki lubang drainase...\n2. Sebarkan biji terong ungu...",
    },
  ];

  List<Plant> _trackedPlants = [];
  List<Plant> _historicalPlants = [];
  String? _historyFilter;
  bool _isInitialized = false;

  // Inisialisasi provider
  Future<void> initialize() async {
    if (_isInitialized) return;
    await _loadPlants();
    _isInitialized = true;
  }

  // Memuat data dari SharedPreferences
  Future<void> _loadPlants() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // Memuat tanaman yang sedang ditrack
      final trackedJson = prefs.getString('tracked_plants');
      if (trackedJson != null) {
        _trackedPlants = (json.decode(trackedJson) as List)
            .map((item) => Plant.fromJson(item))
            .toList();
      }

      // Memuat riwayat tanaman
      final historicalJson = prefs.getString('historical_plants');
      if (historicalJson != null) {
        _historicalPlants = (json.decode(historicalJson) as List)
            .map((item) => Plant.fromJson(item))
            .toList();
      }

      notifyListeners();
    } catch (e) {
      debugPrint('Error loading plants: $e');
    }
  }

  // Menyimpan data ke SharedPreferences
  Future<void> _savePlants() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      await prefs.setString(
        'tracked_plants',
        json.encode(_trackedPlants.map((plant) => plant.toJson()).toList()),
      );

      await prefs.setString(
        'historical_plants',
        json.encode(_historicalPlants.map((plant) => plant.toJson()).toList()),
      );
    } catch (e) {
      debugPrint('Error saving plants: $e');
    }
  }

  // GETTERS
  List<Plant> get trackedPlants => _trackedPlants;

  String? get historyFilter => _historyFilter; // <-- NEW: Add this getter

  List<Plant> get historicalPlants {
    // <-- MODIFIED: Update this getter
    if (_historyFilter == null) {
      return _historicalPlants;
    }
    return _historicalPlants
        .where((plant) => plant.status == _historyFilter)
        .toList();
  }

  List<Plant> get availablePlants => allPlants
      .map((plant) => Plant(
            name: plant["name"]!,
            duration: plant["duration"]!,
            startDate: DateTime.now(),
            progress: 0.0,
            tasks: [
              PlantTask(name: "Penyiraman", completed: false),
              PlantTask(name: "Pemupukan", completed: false),
            ],
            imagePath: plant["image"],
          ))
      .toList();

  // METHOD UTAMA
  void setHistoryFilter(String? filter) {
    _historyFilter = filter;
    notifyListeners();
  }

  Future<void> addPlant(Plant plant) async {
    _trackedPlants.add(plant);
    await _savePlants();
    notifyListeners();
  }

  Future<void> updatePlant(Plant updatedPlant) async {
    final index = _trackedPlants.indexWhere((p) => p.name == updatedPlant.name);
    if (index != -1) {
      // Simpan data penting yang tidak boleh direset
      final originalStartDate = _trackedPlants[index].startDate;
      final originalTasks = _trackedPlants[index].tasks;

      _trackedPlants[index] = updatedPlant.copyWith(
        startDate: originalStartDate, // Pertahankan startDate asli
        tasks: originalTasks, // Pertahankan tasks asli
      );

      await _savePlants();
      notifyListeners();
    }
  }

  Future<void> updatePlantProgress(String plantName, double progress) async {
    final index = _trackedPlants.indexWhere((p) => p.name == plantName);
    if (index != -1) {
      _trackedPlants[index] = _trackedPlants[index].copyWith(
        progress: progress.clamp(0.0, 1.0),
      );
      await _savePlants();
      notifyListeners();
    }
  }

  Future<void> removePlant(String plantName) async {
    _trackedPlants.removeWhere((p) => p.name == plantName);
    await _savePlants();
    notifyListeners();
  }

  Future<void> endPlanting(String plantName, String status) async {
    final index = _trackedPlants.indexWhere((p) => p.name == plantName);
    if (index != -1) {
      final plant = _trackedPlants[index].copyWith(
        endDate: DateTime.now(),
        status: status,
      );

      _historicalPlants.add(plant);
      _trackedPlants.removeAt(index);

      await _savePlants();
      notifyListeners();
    }
  }

  Future<void> addPlantNote(String plantName, String note) async {
    final index = _trackedPlants.indexWhere((p) => p.name == plantName);
    if (index != -1) {
      _trackedPlants[index] = _trackedPlants[index].copyWith(
        notes: note,
      );
      await _savePlants();
      notifyListeners();
    }
  }

  Plant? getPlantByName(String name) {
    try {
      return _trackedPlants.firstWhere((p) => p.name == name);
    } catch (e) {
      return null;
    }
  }

  // Method untuk mengupdate task
  Future<void> updateTaskStatus(
      String plantName, int taskIndex, bool completed) async {
    final plantIndex = _trackedPlants.indexWhere((p) => p.name == plantName);
    if (plantIndex != -1) {
      final updatedTasks =
          List<PlantTask>.from(_trackedPlants[plantIndex].tasks);
      updatedTasks[taskIndex] = updatedTasks[taskIndex].copyWith(
        completed: completed,
        completionDate: completed ? DateTime.now() : null,
      );

      _trackedPlants[plantIndex] = _trackedPlants[plantIndex].copyWith(
        tasks: updatedTasks,
      );

      // Update progress otomatis berdasarkan task
      final completedCount =
          updatedTasks.where((task) => task.completed).length;
      final newProgress =
          updatedTasks.isEmpty ? 0.0 : completedCount / updatedTasks.length;

      _trackedPlants[plantIndex] = _trackedPlants[plantIndex].copyWith(
        progress: newProgress,
      );

      await _savePlants();
      notifyListeners();
    }
  }
}
