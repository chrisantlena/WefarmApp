class Experience {
  final String plantName;
  final DateTime startDate;
  final DateTime endDate;
  final String status;
  final String review;
  final String author;
  final DateTime createdAt;

  Experience({
    required this.plantName,
    required this.startDate,
    required this.endDate,
    required this.status,
    required this.review,
    required this.author,
    required this.createdAt,
  });

  String get formattedStartDate => '${startDate.day}/${startDate.month}/${startDate.year}';
  String get formattedEndDate => '${endDate.day}/${endDate.month}/${endDate.year}';
  String get formattedCreatedAt => '${createdAt.day}/${createdAt.month}/${createdAt.year}';
}