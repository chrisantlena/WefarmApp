
class Plant {
  final String name;
  final String duration;
  final DateTime startDate;
  DateTime? endDate;
  String? status;
  double progress;
  List<PlantTask> tasks;
  String? notes;
  String? imagePath;

  Plant({
    required this.name,
    required this.duration,
    required this.startDate,
    this.endDate,
    this.status,
    this.progress = 0.0,
    required this.tasks,
    this.notes,
    this.imagePath,
  });

  

  factory Plant.fromJson(Map<String, dynamic> json) {
    return Plant(
      name: json['name'],
      duration: json['duration'],
      startDate: DateTime.parse(json['startDate']),
      endDate: json['endDate'] != null ? DateTime.parse(json['endDate']) : null,
      status: json['status'],
      progress: json['progress']?.toDouble() ?? 0.0,
      tasks: (json['tasks'] as List).map((task) => PlantTask.fromJson(task)).toList(),
      notes: json['notes'],
      imagePath: json['imagePath'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'duration': duration,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate?.toIso8601String(),
      'status': status,
      'progress': progress,
      'tasks': tasks.map((task) => task.toJson()).toList(),
      'notes': notes,
      'imagePath': imagePath,
    };
  }

  Plant copyWith({
    String? name,
    String? duration,
    DateTime? startDate,
    DateTime? endDate,
    String? status,
    double? progress,
    List<PlantTask>? tasks,
    String? notes,
    String? imagePath,
  }) {
    return Plant(
      name: name ?? this.name,
      duration: duration ?? this.duration,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      status: status ?? this.status,
      progress: progress ?? this.progress,
      tasks: tasks ?? this.tasks,
      notes: notes ?? this.notes,
      imagePath: imagePath ?? this.imagePath,
    );
  }
}

class PlantTask {
  final String name;
  bool completed;
  DateTime? completionDate;
  String? notes;

  PlantTask({
    required this.name,
    this.completed = false,
    this.completionDate,
    this.notes,
  });

  factory PlantTask.fromJson(Map<String, dynamic> json) {
    return PlantTask(
      name: json['name'],
      completed: json['completed'],
      completionDate: json['completionDate'] != null 
          ? DateTime.parse(json['completionDate']) 
          : null,
      notes: json['notes'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'completed': completed,
      'completionDate': completionDate?.toIso8601String(),
      'notes': notes,
    };
  }

  PlantTask copyWith({
    String? name,
    bool? completed,
    DateTime? completionDate,
    String? notes,
  }) {
    return PlantTask(
      name: name ?? this.name,
      completed: completed ?? this.completed,
      completionDate: completionDate ?? this.completionDate,
      notes: notes ?? this.notes,
    );
  }
}

