import 'package:flutter/material.dart';
import 'package:wefarm/register_screen.dart';
import 'home_screen.dart';
import 'forgot_password_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isPasswordVisible = false; // State untuk toggle visibility password

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(28.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/logo_wefarm.png',
              width: 250,
              height: 250,
            ),
            SizedBox(height: 8.0),
            Align(
              alignment: Alignment.center,
              child: Text(
                "Log In", // Judul "Login"
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: 40.0),

            // Kotak untuk Username dan Password
            Container(
              decoration: BoxDecoration(
                color: Colors.white, // Warna latar belakang container (putih)
                border:
                    Border.all(color: Colors.grey.withOpacity(0.5)), // Border
                borderRadius: BorderRadius.circular(10.0), // Sudut melengkung
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3), // Warna bayangan
                    spreadRadius: 2, // Seberapa jauh bayangan menyebar
                    blurRadius: 5, // Seberapa blur bayangan
                    offset: Offset(0, 3), // Posisi bayangan (x, y)
                  ),
                ],
              ),
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  TextField(
                    decoration: InputDecoration(
                      labelText: 'Username',
                      border: InputBorder.none, // Menghilangkan border default
                      contentPadding:
                          EdgeInsets.symmetric(vertical: 4.0, horizontal: 8.0),
                    ),
                  ),
                  Divider(color: Colors.grey.withOpacity(0.5)), // Garis pemisah
                  TextField(
                    obscureText:
                        !_isPasswordVisible, // Toggle visibility password
                    decoration: InputDecoration(
                      labelText: 'Password',
                      border: InputBorder.none, // Menghilangkan border default
                      contentPadding:
                          EdgeInsets.symmetric(vertical: 4.0, horizontal: 8.0),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _isPasswordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                        ),
                        onPressed: () {
                          setState(() {
                            _isPasswordVisible =
                                !_isPasswordVisible; // Toggle state
                          });
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 20.0),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ForgotPasswordScreen()),
                  );
                },
                child: Text("Forgot Password?"),
              ),
            ),
            SizedBox(height: 30.0),
            ElevatedButton(
              onPressed: () {
                // Navigasi ke HomeScreen setelah login
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomeScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    Color(0xFFf5bd52), // Warna latar belakang tombol
                foregroundColor: Colors.white, // Warna teks tombol
                padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 32.0),
              ),
              child: Text(
                "Log In",
                style: TextStyle(fontSize: 24),
              ),
            ),
            SizedBox(height: 20.0),

            // Opsi Login dengan Google dan Facebook
            Text(
              "Or login with",
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
            SizedBox(height: 16.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Tombol Login dengan Google
                IconButton(
                  onPressed: () {
                    // Aksi login dengan Google
                  },
                  icon: Image.asset(
                    'assets/google_logo.png', // Logo Google
                    width: 30,
                    height: 30,
                  ),
                ),
                SizedBox(width: 20.0),

                // Tombol Login dengan Facebook
                IconButton(
                  onPressed: () {
                    // Aksi login dengan Facebook
                  },
                  icon: Image.asset(
                    'assets/facebook_logo.png', // Logo Facebook
                    width: 30,
                    height: 30,
                  ),
                ),
              ],
            ),

            SizedBox(height: 20.0),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RegisterScreen()),
                );
              },
              child: Text("Don't have an account? Register here"),
            ),
          ],
        ),
      ),
    );
  }
}
