import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';
import '../models/plant_model.dart';
import '../models/plant_provider.dart';
import 'custom_drawer.dart';

class PlantDetailPage extends StatefulWidget {
  final Plant plant;

  const PlantDetailPage({super.key, required this.plant});

  @override
  State<PlantDetailPage> createState() => _PlantDetailPageState();
}

class _PlantDetailPageState extends State<PlantDetailPage> {
  late Plant currentPlant;
  late CalendarFormat _calendarFormat;
  late DateTime _focusedDay;
  final List<Map<String, dynamic>> _notesList = [];
  final TextEditingController _newNoteController = TextEditingController();
  DateTime? _selectedPlantingDate;
  Map<int, bool> _completedTargets = {};
  Map<int, String?> _targetProblems = {};

  @override
  void initState() {
    super.initState();
    currentPlant = widget.plant.copyWith(
      tasks:
          widget.plant.tasks.map((t) => t.copyWith(completed: false)).toList(),
    );
    _calendarFormat = CalendarFormat.month;
    _focusedDay = DateTime.now();
    _selectedPlantingDate = currentPlant.startDate;

    // Inisialisasi notes
    if (currentPlant.notes?.isNotEmpty ?? false) {
      try {
        _notesList.addAll(currentPlant.notes!.split('\n').map((note) {
          final parts = note.split('|');
          return {
            'date': DateTime.parse(parts[0]),
            'content': parts[1],
          };
        }).toList());
      } catch (e) {
        _notesList.add({
          'date': DateTime.now(),
          'content': currentPlant.notes!,
        });
      }
    }

    // Inisialisasi target
    _completedTargets = {
      0: currentPlant.progress >= 0.25,
      1: currentPlant.progress >= 0.5,
      2: currentPlant.progress >= 0.75,
      3: currentPlant.progress >= 1.0,
    };
    _targetProblems = {};
  }

  @override
  void dispose() {
    _newNoteController.dispose();
    super.dispose();
  }

  int _parseDuration(String duration) {
    try {
      final months = duration.split(' ').first.split('-').first;
      return int.parse(months) * 30;
    } catch (e) {
      return 90;
    }
  }

  CalendarStyle _calendarStyle(BuildContext context) {
    return CalendarStyle(
      selectedDecoration: BoxDecoration(
        color: const Color(0xFFf5bd52),
        shape: BoxShape.circle,
      ),
      todayDecoration: BoxDecoration(
        color: const Color(0xFFf5bd52).withOpacity(0.5),
        shape: BoxShape.circle,
      ),
      markerDecoration: BoxDecoration(
        color: Colors.green.withOpacity(0.5),
        shape: BoxShape.circle,
      ),
      markersMaxCount: 1,
    );
  }

  List<dynamic> _getEventsForDay(DateTime day) {
    if (_selectedPlantingDate == null) return [];

    final daysSincePlanting = day.difference(_selectedPlantingDate!).inDays;

    if (daysSincePlanting == 0 ||
        daysSincePlanting == 7 ||
        daysSincePlanting == 14 ||
        daysSincePlanting == 30) {
      return [day];
    }
    return [];
  }

  Future<void> _showPlantingDateDialog() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedPlantingDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: Color(0xFFf5bd52),
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null && picked != _selectedPlantingDate) {
      setState(() {
        _selectedPlantingDate = picked;
        currentPlant = currentPlant.copyWith(startDate: picked);
      });
      _saveChanges();
    }
  }

  void _toggleTask(int index) {
    setState(() {
      final updatedTasks = List<PlantTask>.from(currentPlant.tasks);
      updatedTasks[index] = updatedTasks[index].copyWith(
        completed: !updatedTasks[index].completed,
        completionDate: !updatedTasks[index].completed ? DateTime.now() : null,
      );

      currentPlant = currentPlant.copyWith(tasks: updatedTasks);
      _updateProgressBasedOnTasks();
    });
  }

  void _updateProgressBasedOnTasks() {
    // Cari target tertinggi yang dicentang
    int highestCompleted = -1;
    for (int i = 0; i < 4; i++) {
      if (_completedTargets[i] ?? false) {
        highestCompleted = i;
      } else {
        break;
      }
    }

    // Progress dari target (25% per target)
    final targetProgress = (highestCompleted + 1) * 0.25;

    // Bonus progress dari task harian (maksimal 10%)
    final taskBonus = currentPlant.tasks.isEmpty
        ? 0.0
        : (currentPlant.tasks.where((t) => t.completed).length /
                currentPlant.tasks.length) *
            0.1;

    // Total progress
    final newProgress = (targetProgress + taskBonus).clamp(0.0, 1.0);

    setState(() {
      currentPlant = currentPlant.copyWith(progress: newProgress);
    });
    _saveChanges();
  }

  Future<void> _saveChanges() async {
    final serializedNotes = _notesList
        .map((note) => '${note['date'].toIso8601String()}|${note['content']}')
        .join('\n');

    await Provider.of<PlantProvider>(context, listen: false).updatePlant(
      currentPlant.copyWith(
        notes: serializedNotes,
      ),
    );
  }

  String _formatDate(DateTime? date) {
    if (date == null) return '-';
    return '${date.day}/${date.month}/${date.year}';
  }

  Future<void> _showTargetStatusDialog(int milestoneIndex) async {
    final isCompleted = _completedTargets[milestoneIndex] ?? false;
    final isLocked =
        milestoneIndex > 0 && !(_completedTargets[milestoneIndex - 1] ?? false);

    if (isLocked) return; // Target terkunci tidak bisa diinteraksi

    if (isCompleted) {
      // Jika target sudah dicentang, tampilkan konfirmasi pembatalan
      return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Batalkan Target?'),
            content: const Text(
                'Membatalkan target ini akan membatalkan semua target setelahnya.'),
            actions: <Widget>[
              TextButton(
                child: const Text('Tidak'),
                onPressed: () => Navigator.of(context).pop(),
              ),
              TextButton(
                child: const Text('Ya'),
                onPressed: () {
                  setState(() {
                    // Batalkan target ini dan semua target setelahnya
                    for (int i = milestoneIndex; i < 4; i++) {
                      _completedTargets[i] = false;
                      _targetProblems.remove(i);
                    }
                    _updateProgressBasedOnTasks();
                  });
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    } else {
      // Jika target belum dicentang, tampilkan dialog pilihan
      return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Status Target'),
            content: const Text('Apakah target ini sudah terpenuhi?'),
            actions: <Widget>[
              TextButton(
                child: const Text('Ada Masalah'),
                onPressed: () {
                  Navigator.of(context).pop();
                  _showProblemOptionsDialog(milestoneIndex);
                },
              ),
              TextButton(
                child: const Text('Sudah Terpenuhi'),
                onPressed: () {
                  setState(() {
                    // Centang target ini dan semua target sebelumnya
                    for (int i = 0; i <= milestoneIndex; i++) {
                      _completedTargets[i] = true;
                      _targetProblems.remove(i);
                    }
                    _updateProgressBasedOnTasks();
                  });
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    }
  }

  Future<void> _showProblemOptionsDialog(int milestoneIndex) async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Ada Masalah?'),
          content: const Text('Pilih opsi untuk menangani masalah ini'),
          actions: <Widget>[
            TextButton(
              child: const Text('Tunggu Beberapa Hari'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Baca Artikel Solusi'),
              onPressed: () {
                // Here you would navigate to an article page
                // For now just mark as having problem
                setState(() {
                  _targetProblems[milestoneIndex] = 'Masalah dilaporkan';
                });
                Navigator.of(context).pop();
                _saveChanges();
              },
            ),
          ],
        );
      },
    );
  }

  void _showPlantNotes() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Catatan ${currentPlant.name}',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Text(currentPlant.notes ?? 'Belum ada catatan'),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Tutup'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final estimatedEndDate = _selectedPlantingDate
        ?.add(Duration(days: _parseDuration(currentPlant.duration)));

    return WillPopScope(
      onWillPop: () async {
        // Kembalikan plant yang sudah diupdate saat back
        Navigator.pop(context, currentPlant);
        return false;
      },
      child: Scaffold(
        endDrawer: const CustomDrawer(currentIndex: -1),
        appBar: AppBar(
          title: Text(currentPlant.name),
          backgroundColor: const Color(0xFFf5bd52),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.note),
              onPressed: _showPlantNotes,
              tooltip: 'Catatan',
            ),
            Builder(
              builder: (context) => IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () => Scaffold.of(context).openEndDrawer(),
              ),
            ),
          ],
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TableCalendar(
                        firstDay: _selectedPlantingDate ?? DateTime.now(),
                        lastDay: (_selectedPlantingDate ?? DateTime.now())
                            .add(const Duration(days: 365)),
                        focusedDay: _focusedDay,
                        calendarFormat: _calendarFormat,
                        calendarStyle: _calendarStyle(context),
                        headerStyle: const HeaderStyle(
                          formatButtonVisible: false, // Disable format changing
                          titleCentered: true,
                        ),
                        eventLoader: _getEventsForDay,
                        selectedDayPredicate: (day) {
                          return isSameDay(_selectedPlantingDate, day);
                        },
                        onDaySelected: null, // Disable date selection
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Mulai: ${_formatDate(_selectedPlantingDate)}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'Estimasi Panen: ${_formatDate(estimatedEndDate)}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              _buildProgressSection(),
              const SizedBox(height: 16),
              _buildMilestonesSection(),
              const SizedBox(height: 16),
              _buildTasksSection(),
              const SizedBox(height: 16),
              _buildNotesSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProgressSection() {
    final completedTargets = _completedTargets.values.where((c) => c).length;
    final completedTasks = currentPlant.tasks.where((t) => t.completed).length;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Progress: ${(currentPlant.progress * 100).toStringAsFixed(0)}%",
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(
                  "Target: ${currentPlant.duration}",
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ],
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: currentPlant.progress,
              minHeight: 10,
              backgroundColor: Colors.grey[200],
              color: const Color(0xFFf5bd52),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Target: $completedTargets/4",
                  style: const TextStyle(fontSize: 12),
                ),
                Text(
                  "Task: $completedTasks/${currentPlant.tasks.length}",
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMilestonesSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Target Perkembangan:",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            _buildMilestoneItem("Hari 1-7", "Muncul akar kecil", 0),
            _buildMilestoneItem("Hari 7-14", "Daun pertama muncul", 1),
            _buildMilestoneItem("Hari 14-30", "Batang mengeras dan tumbuh", 2),
            _buildMilestoneItem("Hari 30+", "Siap panen", 3),
          ],
        ),
      ),
    );
  }

  Widget _buildMilestoneItem(
      String period, String description, int milestoneIndex) {
    final isCompleted = _completedTargets[milestoneIndex] ?? false;
    final hasProblem = _targetProblems[milestoneIndex] != null;
    final isLocked =
        milestoneIndex > 0 && !(_completedTargets[milestoneIndex - 1] ?? false);

    return InkWell(
      onTap: isLocked ? null : () => _showTargetStatusDialog(milestoneIndex),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            if (isLocked)
              const Icon(Icons.lock_outline, color: Colors.grey)
            else if (isCompleted)
              const Icon(Icons.check_circle, color: Colors.green)
            else if (hasProblem)
              const Icon(Icons.error, color: Colors.red)
            else
              const Icon(Icons.radio_button_unchecked, color: Colors.grey),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    period,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: hasProblem
                          ? Colors.red
                          : isLocked
                              ? Colors.grey
                              : null,
                      decoration:
                          isCompleted ? TextDecoration.lineThrough : null,
                    ),
                  ),
                  Text(
                    description,
                    style: TextStyle(
                      color: hasProblem
                          ? Colors.red
                          : isLocked
                              ? Colors.grey
                              : null,
                      decoration:
                          isCompleted ? TextDecoration.lineThrough : null,
                    ),
                  ),
                  if (hasProblem)
                    Text(
                      _targetProblems[milestoneIndex]!,
                      style: const TextStyle(
                        color: Colors.red,
                        fontSize: 12,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTasksSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Tugas Harian:",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            ...currentPlant.tasks.asMap().entries.map((entry) {
              final index = entry.key;
              final task = entry.value;
              return CheckboxListTile(
                title: Text(
                  task.name,
                  style: TextStyle(
                    decoration:
                        task.completed ? TextDecoration.lineThrough : null,
                    color: task.completed ? Colors.grey : null,
                  ),
                ),
                subtitle: task.completionDate != null
                    ? Text(
                        "Terakhir: ${_formatDate(task.completionDate)}",
                        style: const TextStyle(fontSize: 12),
                      )
                    : null,
                value: task.completed,
                onChanged: (value) => _toggleTask(index),
                activeColor: const Color(0xFFf5bd52),
                controlAffinity: ListTileControlAffinity.leading,
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildNotesSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Catatan:",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),

            // Daftar catatan
            ..._notesList.reversed.map((note) {
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _formatDate(note['date']),
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(note['content']),
                    ],
                  ),
                ),
              );
            }).toList(),

            // Input catatan baru
            TextField(
              controller: _newNoteController,
              maxLines: 3,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: "Tambahkan catatan baru...",
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFf5bd52),
                    ),
                    onPressed: () {
                      if (_newNoteController.text.trim().isNotEmpty) {
                        setState(() {
                          _notesList.add({
                            'date': DateTime.now(),
                            'content': _newNoteController.text,
                          });
                          _newNoteController.clear();
                        });
                        _saveChanges();
                      }
                    },
                    child: const Text("Tambah Catatan"),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
