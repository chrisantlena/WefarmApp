import 'package:flutter/material.dart';

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Forgot Password"),
        backgroundColor: Color(0xFFf5bd52), // Warna app bar sesuai tema
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Forgot Password",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              "Please enter your email address to receive a password reset link.",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
            SizedBox(height: 24.0),

            // Kotak Input Email
            Container(
              decoration: BoxDecoration(
                color: Colors.white, // Warna latar belakang container (putih)
                border:
                    Border.all(color: Colors.grey.withOpacity(0.5)), // Border
                borderRadius: BorderRadius.circular(10.0), // Sudut melengkung
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3), // Warna bayangan
                    spreadRadius: 2, // Seberapa jauh bayangan menyebar
                    blurRadius: 5, // Seberapa blur bayangan
                    offset: Offset(0, 3), // Posisi bayangan (x, y)
                  ),
                ],
              ),
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: InputBorder.none, // Menghilangkan border default
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 5.0, horizontal: 16.0),
                ),
              ),
            ),

            SizedBox(height: 16.0),

            // Tombol Submit
            ElevatedButton(
              onPressed: () {
                // Aksi untuk mengirim email reset password
                // Anda bisa menambahkan logika pengiriman email di sini
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                        "Password reset link has been sent to your email."),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFFf5bd52), // Warna tombol
                foregroundColor: Colors.white, // Warna teks tombol
                padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 32.0),
              ),
              child: Text(
                "Submit",
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
