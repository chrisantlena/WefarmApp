// main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'models/experience_provider.dart';
import 'models/plant_provider.dart';
import 'models/user_provider.dart';
import 'splash_screen.dart';
import 'package:timeago/timeago.dart' as timeago;

void main() async {
  timeago.setLocaleMessages('en_short', timeago.EnShortMessages());
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
            create: (context) => PlantProvider()..initialize()),
        ChangeNotifierProvider(create: (context) => ExperienceProvider()),
        ChangeNotifierProvider(create: (context) => UserProvider()..loadUser()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const SplashScreen(),
    );
  }
}